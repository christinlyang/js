A Pen created at CodePen.io. You can find this one at http://codepen.io/mor10/pen/eGmzy.

 Baseline markup for icon font + CSS social tabs to be used wherever. Each button swaps color with the icon when hovered. 