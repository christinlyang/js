A Pen created at CodePen.io. You can find this one at http://codepen.io/Indzign/pen/MwMEgX.

 Cara Memasang Multi Tab di Sidebar Blog 

indzign.blogspot.com