A Pen created at CodePen.io. You can find this one at http://codepen.io/Reklino/pen/xbaKJJ.

 Simple little icon tabs. The animation and visuals are pure css. JS is just used for the events.