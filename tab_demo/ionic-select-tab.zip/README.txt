A Pen created at CodePen.io. You can find this one at http://codepen.io/calendee/pen/Lszbq.

 How to choose what tab to load.
Forum : 4165