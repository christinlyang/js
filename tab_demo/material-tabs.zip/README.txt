A Pen created at CodePen.io. You can find this one at http://codepen.io/MrGrigri/pen/wKmNKB.

 My attempt to overflow tabs naturally using material design