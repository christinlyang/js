A Pen created at CodePen.io. You can find this one at http://codepen.io/adobewordpress/pen/gbewLV.

 Search input for Bootstrap grid with jQuery